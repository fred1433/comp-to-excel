comparable-1-entered.xlsx: the delivered workbook (column D, Comparable 1).
evidence.json: every field, its cell, the rule applied and each source with URL, page, lines and quote.
approval-and-write-receipt.json: the approval (version hash, destination), the cell map and every write attempt.
acceptance-result.json: part-by-part comparison, formula manifest check and the tampering tests.
Code and recorded run: https://github.com/fred1433/comp-to-excel
